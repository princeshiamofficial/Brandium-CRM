import { o as __toESM } from "../_runtime.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { bt as Eye, et as Mail, nt as LogIn, rt as Lock, xt as EyeOff } from "../_libs/lucide-react.mjs";
import { o as fetchMySQLUsers } from "./auth.functions-CZQ1SZaf.mjs";
import { t as supabase } from "./client-D4IcVeb2.mjs";
import { n as useAuth } from "./auth-DCy2dymu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as AccountSuspendedModal } from "./account-suspended-modal-BFAdRICc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-zP3aiADR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const navigate = useNavigate();
	const { session, loading, setAuthenticatedDbSession } = useAuth();
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [suspendedModalOpen, setSuspendedModalOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!loading && session) navigate({
			to: "/dashboard",
			replace: true
		});
	}, [
		loading,
		session,
		navigate
	]);
	async function performLogin(targetEmail, targetPass) {
		setSubmitting(true);
		setEmail(targetEmail);
		setPassword(targetPass);
		try {
			const { users } = await fetchMySQLUsers();
			const target = users.find((u) => String(u["email"] || "").toLowerCase() === targetEmail.trim().toLowerCase());
			if (target && (String(target["status"] || "") !== "Active" || Boolean(target["is_deleted"]))) {
				setSubmitting(false);
				setSuspendedModalOpen(true);
				return;
			}
		} catch {}
		const { data, error } = await supabase.auth.signInWithPassword({
			email: targetEmail,
			password: targetPass
		});
		if (error || !data?.user) {
			setSubmitting(false);
			toast.error(error?.message || "Invalid email or password. Please check your credentials.");
			return;
		}
		const userId = data.user.id;
		const userName = data.user.user_metadata?.full_name || targetEmail.split("@")[0] || "User";
		const userRole = data.user.user_metadata?.role || "agent";
		setAuthenticatedDbSession(userId, userName, targetEmail, userRole);
		setSubmitting(false);
		toast.success(`Signed in successfully as ${userName} (${userRole.toUpperCase()})!`);
		navigate({
			to: "/dashboard",
			replace: true
		});
	}
	async function handleSignIn(e) {
		e.preventDefault();
		await performLogin(email, password);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen w-full flex flex-col justify-between overflow-hidden bg-[#0B3364] select-none font-sans",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 bg-cover bg-center bg-no-repeat transition-all duration-700",
				style: { backgroundImage: `url('/brandium_login_bg.jpg')` }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-slate-950/10 pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-slate-950/20 via-transparent to-black/10 pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "relative z-10 p-6 md:p-8 lg:px-56 xl:px-80 flex items-center justify-between",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/login",
					className: "flex items-center gap-2.5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/logo.png",
						alt: "Brandium Logo",
						className: "h-10 md:h-12 w-auto object-contain drop-shadow-md"
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "relative z-10 flex-1 flex items-center justify-center p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-100 bg-white/85 backdrop-blur-2xl border border-white/90 shadow-[0_25px_60px_rgba(0,0,0,0.18)] rounded-[32px] p-8 md:p-9 text-center transition-all",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-11 rounded-xl bg-white shadow-xs border border-slate-100 flex items-center justify-center mx-auto mb-4 text-slate-800",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogIn, { className: "size-4 text-slate-800 stroke-2" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-xl font-bold text-slate-900 tracking-tight mb-1",
							children: "Sign In"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-500 font-normal leading-relaxed mb-6",
							children: "Enter your details to access your account"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: handleSignIn,
							className: "space-y-3 text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 size-4 text-slate-400 pointer-events-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "email",
										required: true,
										autoComplete: "email",
										value: email,
										onChange: (e) => setEmail(e.target.value),
										placeholder: "Email",
										className: "w-full h-11 rounded-xl bg-white border border-slate-200/80 shadow-2xs px-3.5 pl-10 text-xs font-medium text-slate-800 placeholder:text-slate-400 focus:border-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-200 transition-all"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 size-4 text-slate-400 pointer-events-none" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: showPassword ? "text" : "password",
											required: true,
											autoComplete: "current-password",
											value: password,
											onChange: (e) => setPassword(e.target.value),
											placeholder: "Password",
											className: "w-full h-11 rounded-xl bg-white border border-slate-200/80 shadow-2xs px-3.5 pl-10 pr-10 text-xs font-medium text-slate-800 placeholder:text-slate-400 focus:border-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-200 transition-all"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setShowPassword(!showPassword),
											className: "absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors",
											children: showPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" })
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex justify-end pt-0.5",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => toast.info("Contact administrator to reset password."),
										className: "text-[11px] font-medium text-slate-500 hover:text-slate-800 transition-colors",
										children: "Forgot password?"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									disabled: submitting,
									className: "w-full h-11 rounded-xl bg-[#0B3364] hover:bg-[#08264b] text-white font-semibold text-xs shadow-md shadow-[#0B3364]/20 transition-all cursor-pointer disabled:opacity-75 mt-1",
									children: submitting ? "Signing in..." : "Sign In"
								}),
								false
							]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "relative z-10 p-6 text-center text-xs text-white/70 font-medium",
				children: "© 2026 Brandium CRM. All rights reserved."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountSuspendedModal, {
				open: suspendedModalOpen,
				onOpenChange: setSuspendedModalOpen
			})
		]
	});
}
//#endregion
export { LoginPage as component };
