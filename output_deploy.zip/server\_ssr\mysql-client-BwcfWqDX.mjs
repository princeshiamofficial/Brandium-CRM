import { o as __toESM } from "../_runtime.mjs";
import fs from "fs";
import path from "path";
//#region node_modules/.nitro/vite/services/ssr/assets/mysql-client-BwcfWqDX.js
/**
* Standalone MySQL Database Engine & Connection Helper.
* Server code reads secrets from MYSQL_* only; client-visible VITE_* values are limited to non-secret hints.
*/
var envLoaded = false;
function loadEnvFromFile() {
	if (envLoaded || typeof process === "undefined" || !process.versions?.node) return;
	envLoaded = true;
	try {
		const cwd = process.cwd();
		const envPaths = [path.resolve(cwd, ".env"), "/home/crm.brandiumagency.com/public_html/.env"];
		for (const envPath of envPaths) if (fs.existsSync(envPath)) {
			const content = fs.readFileSync(envPath, "utf-8");
			for (const line of content.split("\n")) {
				const trimmed = line.trim();
				if (!trimmed || trimmed.startsWith("#")) continue;
				const eqIdx = trimmed.indexOf("=");
				if (eqIdx > 0) {
					const key = trimmed.slice(0, eqIdx).trim();
					let val = trimmed.slice(eqIdx + 1).trim();
					if (val.startsWith("\"") && val.endsWith("\"") || val.startsWith("'") && val.endsWith("'")) val = val.slice(1, -1);
					if (!process.env[key]) process.env[key] = val;
				}
			}
			break;
		}
	} catch {}
}
function getMySQLConfig() {
	loadEnvFromFile();
	const serverEnv = typeof process !== "undefined" ? process.env : void 0;
	const clientEnv = typeof import.meta !== "undefined" ? {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/"
	} : void 0;
	const rawHost = serverEnv?.["MYSQL_HOST"] || clientEnv?.["VITE_MYSQL_HOST"] || "127.0.0.1";
	const host = rawHost === "localhost" ? "127.0.0.1" : rawHost;
	const port = parseInt(serverEnv?.["MYSQL_PORT"] || clientEnv?.["VITE_MYSQL_PORT"] || "3306", 10);
	const user = serverEnv?.["MYSQL_USER"] || clientEnv?.["VITE_MYSQL_USER"] || "crm_brandium";
	const password = serverEnv?.["MYSQL_PASSWORD"] !== void 0 && serverEnv["MYSQL_PASSWORD"] !== "" ? serverEnv["MYSQL_PASSWORD"] : clientEnv?.["VITE_MYSQL_PASSWORD"] !== void 0 && clientEnv["VITE_MYSQL_PASSWORD"] !== "" ? clientEnv["VITE_MYSQL_PASSWORD"] : "Brandium456";
	const database = serverEnv?.["MYSQL_DATABASE"] || clientEnv?.["VITE_MYSQL_DATABASE"] || "crm_brandium";
	const connectionLimit = parseInt(serverEnv?.["MYSQL_CONNECTION_LIMIT"] || "20", 10);
	return {
		host,
		port: Number.isFinite(port) ? port : 3306,
		user,
		password,
		database,
		connectionLimit: Number.isFinite(connectionLimit) ? connectionLimit : 20
	};
}
function checkDatabaseConnection() {
	if (typeof window === "undefined") return false;
	return true;
}
var globalPool = null;
async function getMySQLPool() {
	if (globalPool) return globalPool;
	const mysqlModule = await import("../_libs/mysql2+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
	const config = getMySQLConfig();
	globalPool = mysqlModule.default.createPool({
		host: config.host === "localhost" ? "127.0.0.1" : config.host,
		port: config.port,
		user: config.user,
		password: config.password ?? "",
		database: config.database,
		waitForConnections: true,
		connectionLimit: config.connectionLimit,
		queueLimit: 0,
		enableKeepAlive: true,
		keepAliveInitialDelay: 1e4,
		charset: "utf8mb4"
	});
	return globalPool;
}
/**
* Utility to generate standard 36-character RFC4122 v4 UUIDs using Web/Node Crypto.
* Compliant with MySQL VARCHAR(36) primary key schema definitions.
*/
function generateUUID() {
	try {
		if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
		const globalCrypto = typeof window !== "undefined" ? window.crypto : void 0;
		if (globalCrypto && typeof globalCrypto.randomUUID === "function") return globalCrypto.randomUUID();
	} catch {}
	return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
		const r = Math.random() * 16 | 0;
		return (c === "x" ? r : r & 3 | 8).toString(16);
	});
}
//#endregion
export { getMySQLPool as i, generateUUID as n, getMySQLConfig as r, checkDatabaseConnection as t };
