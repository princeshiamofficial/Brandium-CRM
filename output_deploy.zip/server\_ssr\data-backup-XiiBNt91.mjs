import { t as AdminBackupPage } from "./backup-nvXjM_-W.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/data-backup-XiiBNt91.js
var SplitComponent = AdminBackupPage;
//#endregion
export { SplitComponent as component };
